# =============================================================================
# Author              : Ajith Kumar Jayamoorthy
# Department          : M.S. Robotics Engineering
# Course              : CS-539 Machine Learning
# File Description    : Decision Tree - ID3 algorithm (Homework 1)
# Date last updated   : 09/07/2021
# =============================================================================

import math
import numpy as np
import pandas as pd
from collections import Counter


# Note: please don't add any new package, you should solve this problem using only the packages above.
#-------------------------------------------------------------------------
'''
    Part 1: Decision Tree (with Discrete Attributes) -- 60 points --
    In this problem, you will implement the decision tree method for classification problems.
    You could test the correctness of your code by typing `nosetests -v test1.py` in the terminal.
'''
        
#-----------------------------------------------
class Node:
    '''
        Decision Tree Node (with discrete attributes)
        Inputs: 
            X: the data instances in the node, a numpy matrix of shape p by n.
               Each element can be int/float/string.
               Here n is the number data instances in the node, p is the number of attributes.
            Y: the class labels, a numpy array of length n.
               Each element can be int/float/string.
            i: the index of the attribute being tested in the node, an integer scalar 
            C: the dictionary of attribute values and children nodes. 
               Each (key, value) pair represents an attribute value and its corresponding child node.
            isleaf: whether or not this node is a leaf node, a boolean scalar
            p: the label to be predicted on the node (i.e., most common label in the node).
    '''
    def __init__(self,X,Y, i=None,C=None, isleaf= False,p=None):
        self.X = X
        self.Y = Y
        self.i = i
        self.C= C
        self.isleaf = isleaf
        self.p = p


#-----------------------------------------------
class Tree(object):
    '''
        Decision Tree (with discrete attributes). 
        We are using ID3(Iterative Dichotomiser 3) algorithm. So this decision tree is also called ID3.
    '''
    #--------------------------
    @staticmethod
    def entropy(Y):
        '''
            Compute the entropy of a list of values.
            Input:
                Y: a list of values, a numpy array of int/float/string values.
            Output:
                e: the entropy of the list of values, a float scalar
            Hint: you could use collections.Counter.
        '''
        #########################################
        ## INSERT YOUR CODE HERE
        ## Parent Node Entropy Calculation

        target_length = len(Y)                                      # The length of the input Y label array is calculated
        count = Counter(Y)                                          # The number of labels for each target class is caluclated and stored in variable count
        e = 0.0                                                     # Initializing a float variable for entropy
        for i in count:                                             # Running a loop for each target class count
            probability = count[i] / target_length                  # Calculating the probability of each target class
            entropy = - (probability * math.log(probability, 2))    # Calculating the entropy for each class
            e += entropy                                            # Summing up all the entropy to get the parent entropy
    
        #########################################
        return e 
    
    
            
    #--------------------------
    @staticmethod
    def conditional_entropy(Y,X):
        '''
            Compute the conditional entropy of y given x. The conditional entropy H(Y|X) means average entropy of children nodes, given attribute X. Refer to https://en.wikipedia.org/wiki/Information_gain_in_decision_trees
            Input:
                X: a list of values , a numpy array of int/float/string values. The size of the array means the number of instances/examples. X contains each instance's attribute value. 
                Y: a list of values, a numpy array of int/float/string values. Y contains each instance's corresponding target label. For example X[0]'s target label is Y[0]
            Output:
                ce: the conditional entropy of y given x, a float scalar
        '''
        #########################################
        ## INSERT YOUR CODE HERE
        ## Parent Node Entropy Calculation (Weighted average)
        

        ce=0.0                                              # Intializing a variable for condition entropy
        X_crosstab = pd.crosstab(X,Y,margins = False)       # Creating a cross tab where each attribute class has a count of target variable for that particular combination
        X_crosstab = X_crosstab.to_numpy()                  # Converting the dataframe to numpy
        r_sum = np.sum(X_crosstab,axis=1)                   # Summing the total label with respect to each sub-category of the attribute
        tot_sum = np.sum(X_crosstab)                        # Calculating the total number of labels belong to the parent attribute
        for j in range(X_crosstab.shape[0]):                # Loop to calculate the weighted average entropy of the children nodes
            cond_ent = 0.0                                  # Initialization of local variable for conditional entropy for each attribute sub-category
            for k in range(X_crosstab.shape[1]):            # Loop to calculate the conditional entropy of each attribute sub-category
                prob1 = float(X_crosstab[j,k]/r_sum[j])     
                if prob1!=0:                                # Checking of the probability is not zero, if in case zero then the entire term is zero
                    cond_ent -= prob1*(math.log(prob1, 2))  
            prob2 = r_sum[j]/tot_sum                        # Calcualting the weights for each of the attribute sub-category for weighted averaging 
            ce += prob2 * cond_ent                          # Calculating the sum of total weighted average for a given attribute children

        return ce 
    
    
    
    #--------------------------
    @staticmethod
    def information_gain(Y,X):
        '''
            Compute the information gain of y after spliting over attribute x
            InfoGain(Y,X) = H(Y) - H(Y|X) 
            Input:
                X: a list of values, a numpy array of int/float/string values.
                Y: a list of values, a numpy array of int/float/string values.
            Output:
                g: the information gain of y after spliting over x, a float scalar
        '''
        #########################################
        ## INSERT YOUR CODE HERE
        ## Calulating information gain for each attribute
        
        g = Tree.entropy(Y) - Tree.conditional_entropy(Y,X) # Subtracting the children entropy from the parent entropy for each attribute... 
                                                            # ...to calculate the information gain
 
        #########################################
        return g


    #--------------------------
    @staticmethod
    def best_attribute(X,Y):
        '''
            Find the best attribute to split the node. 
            Here we use information gain to evaluate the attributes. 
            If there is a tie in the best attributes, select the one with the smallest index.
            Input:
                X: the feature matrix, a numpy matrix of shape p by n. 
                   Each element can be int/float/string.
                   Here n is the number data instances in the node, p is the number of attributes.
                Y: the class labels, a numpy array of length n. Each element can be int/float/string.
            Output:
                i: the index of the attribute to split, an integer scalar
        '''
        #########################################
        ## INSERT YOUR CODE HERE
        ## Calculating the best attribute by finding the attribute with the maximum information gain for each node
        
        best_gain = 0.0                                 # Initializing a variable to store best gain
        i=0                                             # Initializing a variable to store the index of best gain
        for j in range(X.shape[0]):                     # Running loop to range of number of total attributes available for each node
            gain = Tree.information_gain(Y,X[j,:])      # Function call for information gain calculation for each node
            if gain > best_gain:                        # Checking if the info_gain of previous attribute is better than the current attribute
                best_gain = gain                        # Replacing the best_gain value if the current attribute has a better information_gain than previous attribute
                i=j                                     # Saving the index of the attribute to be decided as the root node 
                
        #########################################
        return i

        
    #--------------------------
    @staticmethod
    def split(X,Y,i):
        '''
            Split the node based upon the i-th attribute.
            (1) split the matrix X based upon the values in i-th attribute
            (2) split the labels Y based upon the values in i-th attribute
            (3) build children nodes by assigning a submatrix of X and Y to each node
            (4) build the dictionary to combine each  value in the i-th attribute with a child node.
    
            Input:
                X: the feature matrix, a numpy matrix of shape p by n.
                   Each element can be int/float/string.
                   Here n is the number data instances in the node, p is the number of attributes.
                Y: the class labels, a numpy array of length n.
                   Each element can be int/float/string.
                i: the index of the attribute to split, an integer scalar
            Output:
                C: the dictionary of attribute values and children nodes. 
                   Each (key, value) pair represents an attribute value and its corresponding child node.
        '''
        #########################################
        ## INSERT YOUR CODE HERE
        ## Splitting the best attribute into children nodes
        '''
        i=0
        C = {}
        count = Counter(X[i,:])
        n = X.shape[1]
        for k in count:
            indices = []
            for j in range(n):
                if X[i,j]==k:
                    indices.append(j)
            x_attribute = X[:,indices]
            y_attribute = Y[indices]
            C[k] = Node(x_attribute,y_attribute)
        '''
        
        count = Counter(X[i,:])                     # Counting the number of samples in X with best attribute index i
        C = {}                                      # Initializing an empty dictionary C                                    
        for j in count:                             # Running loop for the attribute sub-categories
            indices = np.where(X[i,:] == j)[0]      # Assinging an array "Indices" to store all the index when the values of X match with the attribute sub-category
            X_attribute = X[:,indices]              # Storing all the attribute in another array X_attribute
            Y_attribute = Y[indices]                # Storing all the labels in another array Y_attribute    
            C[j] = Node(X_attribute, Y_attribute)   # Creating n instances of node with these attributes and labels and storing it in the dictionary as particular sub-category...            
                                                    #...creating n (Number of sub-categories in an attribute) children nodes, stored in the dictionary.
                                                    # These X values act as the input X values act as data for parent entropy calculation for further splitting. 

        #########################################
        return C

    #--------------------------
    @staticmethod
    def stop1(Y):
        '''
            Test condition 1 (stop splitting): whether or not all the instances have the same label. 
    
            Input:
                Y: the class labels, a numpy array of length n.
                   Each element can be int/float/string.
            Output:
                s: whether or not Conidtion 1 holds, a boolean scalar. 
                True if all labels are the same. Otherwise, false.
        '''
        #########################################
        ## INSERT YOUR CODE HERE
        ## Funtion call to verify condition to stop splitting
        
        count = Counter(Y)      # Counting the number of classes in the target label           
        k = len(count)          # Calculating the number of classes in the count             
        if  k < 2:              # If target label is 1 then the leaf has been reached, else we can split.
            s = True            # If leaf has been reached, then stop (Stop = True)
        else:
            s = False           # Else we can continue split (Stop = FALSE)

        #########################################
        return s
    
    #--------------------------
    @staticmethod
    def stop2(X):
        '''
            Test condition 2 (stop splitting): whether or not all the instances have the same attribute values. 
            Input:
                X: the feature matrix, a numpy matrix of shape p by n.
                   Each element can be int/float/string.
                   Here n is the number data instances in the node, p is the number of attributes.
            Output:
                s: whether or not Condition 2 holds, a boolean scalar. 
        '''
        #########################################
        ## INSERT YOUR CODE HERE
        ## Checking if for each attribute the sub-categories are homogeneous. If not,then the 
        s = True                        # Initializing boolean variable to True
        p = X.shape[0]
        for i in range(p):     # Running loop for the number of attributes available
            count = Counter(X[i,:])     # Counting the number of attributes left
            if len(count) >= 2:         # If the number of attributes is greater than one
                s = False               # Then the splitting can continue (Stop = FALSE)
                break
            
        #########################################
        return s
    
            
    #--------------------------
    @staticmethod
    def most_common(Y):
        '''
            Get the most-common label from the list Y. 
            Input:
                Y: the class labels, a numpy array of length n.
                   Each element can be int/float/string.
                   Here n is the number data instances in the node.
            Output:
                y: the most common label, a scalar, can be int/float/string.
        '''
        #########################################
        ## INSERT YOUR CODE HERE
        count = Counter(Y)                  # Counts the number of target labels and their frequency
        y = count.most_common()[0][0]       # The most common function gives the list of instances in the decending order of their frequence of occurance. 
                                            # So, the [0][0] position is the element with the highest occurance.
        #########################################
        return y
    
    
    
    #--------------------------
    @staticmethod
    def build_tree(t):
        '''
            Recursively build tree nodes.
            Input:
                t: a node of the decision tree, without the subtree built.
                t.X: the feature matrix, a numpy float matrix of shape p by n.
                   Each element can be int/float/string.
                    Here n is the number data instances, p is the number of attributes.
                t.Y: the class labels of the instances in the node, a numpy array of length n.
                t.C: the dictionary of attribute values and children nodes. 
                   Each (key, value) pair represents an attribute value and its corresponding child node.
        '''
        #########################################
        ## INSERT YOUR CODE HERE
        ## Building a decision tree from root note
        
        t.p = Tree.most_common(t.Y)                 # We intialize the most common output to Node t's p variable...
                                                    # ...we do this so that for every best attribute we are finding,saved in Node instances,... 
                                                    # ...we are defining the most common output which could be used for prediction of new samples.
                                                    
        if Tree.stop1(t.Y) or Tree.stop2(t.X):      # Checking the condition if we have reached a leaf node... 
                                                    #...(i.e) if the taget labels are homogeneous or if only one attribue is left.
                                                    
            t.isleaf = True                         # if either of the condition turns out to be true, then we have reached the leaf node.
            
        else:                                       # If not the leaf node
            t.i = Tree.best_attribute(t.X,t.Y)      # Finding the index of the next best attribute from the children node
            t.C = Tree.split(t.X, t.Y, t.i)         # Creating the dictionary to store all information of the children node...
                                                    # ...(Their attributes and respective labels in nodes)
            
            for i in t.C:                           # Running the loop throught the parent nodes for a children node input X and Y
                Tree.build_tree(t.C[i])             # passing the children node into the build tree function for finding the next best attribute... 
                                                    # ...and building the tree with the reamaining attributes...  
                                                    #...and respective samples belonging to the children nodes
        
        #########################################
    
    
    #--------------------------
    @staticmethod
    def train(X, Y):
        '''
            Given a training set, train a decision tree. 
            Input:
                X: the feature matrix, a numpy matrix of shape p by n.
                   Each element can be int/float/string.
                   Here n is the number data instances in the training set, p is the number of attributes.
                Y: the class labels, a numpy array of length n.
                   Each element can be int/float/string.
            Output:
                t: the root of the tree.
        '''
        #########################################
        ## INSERT YOUR CODE HERE
        t = Node(X, Y)                      # We are randomly initializing the root note of the tree
        Tree.build_tree(t)                  # The root node of the tree gets trained as the tree builds on
        #########################################
        return t
    
    
    
    #--------------------------
    @staticmethod
    def inference(t,x):
        '''
            Given a decision tree and one data instance, infer the label of the instance recursively. 
            Input:
                t: the root of the tree.
                x: the attribute vector, a numpy vectr of shape p.
                   Each attribute value can be int/float/string.
            Output:
                y: the class labels, a numpy array of length n.
                   Each element can be int/float/string.
        '''
        #########################################
        ## INSERT YOUR CODE HERE
        ## Function to compare with the nodes and reach a leaf node which provides the target label for the sample. 
        
        y = t.p                                         # We are initializing a target variable y with the most common label of the input node
        if t.isleaf == False:                           # Checking if leaf node has been reached after iteration
            for i in range(len(x)):                     
                if x[i] in t.C:                         # Checking for the attribute correspoding to the root node
                    y = Tree.inference(t.C[x[i]],x)     # If the attribute matched the root node, then the children node (corresponding to the attribute sub-category)...
                                                        # ...in the dictionary of the attributes is passed into... 
                                                        # ...the inference function again along with the x values.
                    
        # Following the above steps, finally y is assigned the most common value of the leaf node and that is returned as the output.
        #########################################
        return y
    
    #--------------------------
    @staticmethod
    def predict(t,X):
        '''
            Given a decision tree and a dataset, predict the labels on the dataset. 
            Input:
                t: the root of the tree.
                X: the feature matrix, a numpy matrix of shape p by n.
                   Each element can be int/float/string.
                   Here n is the number data instances in the dataset, p is the number of attributes.
            Output:
                Y: the class labels, a numpy array of length n.
                   Each element can be int/float/string.
        '''
        #########################################
        ## INSERT YOUR CODE HERE
        ## Predicting out for mutiple test samples
        
        Y = []                          # Creating a prediction array for n samples
        n = X.shape[1]                  # Storing the number of samples in the input array
        for i in range(n):              # Running the index from 0 to n
            x = X[:,i]                  # Extracting each sample from the input array
            y = Tree.inference(t,x)     # Calling the inference function to predict the label for the input sample
            Y.append(y)                 # appending the predicted label for each sample into the Y list
        Y = np.array(Y)                 # Converting list to array to be passed

        #########################################
        return Y



    #--------------------------
    @staticmethod
    def load_dataset(filename = 'data1.csv'):
        '''
            Load dataset 1 from the CSV file: 'data1.csv'. 
            The first row of the file is the header (including the names of the attributes)
            In the remaining rows, each row represents one data instance.
            The first column of the file is the label to be predicted.
            In remaining columns, each column represents an attribute.
            Input:
                filename: the filename of the dataset, a string.
            Output:
                X: the feature matrix, a numpy matrix of shape p by n.
                   Each element can be int/float/string.
                   Here n is the number data instances in the dataset, p is the number of attributes.
                Y: the class labels, a numpy array of length n.
                   Each element can be int/float/string.
        '''
        #########################################
        ## INSERT YOUR CODE HERE      
        #filename = 'D:/Sem_1 (Fall_2021)/Machine Learning/Class 3 - Decision Trees & Overfitting , Evaluation/hw1/data1.csv' # Filename to be loaded
        data = np.genfromtxt(filename, delimiter=',',dtype='str')  # Loading data from the csv file in the text format into an numpy matrix of strings

        X           = data[1:,1:]                                       # Removing the first column (mpg- label) and first row (attribute names) and creating the X matrix.
        X           = X.T                                               # Transposing the X matrix from n-by-p dimension to p-by-n dimension
        Y           = data[1:,0]                                        # Storing mpg column into the Y label array
        #########################################
        return X,Y


