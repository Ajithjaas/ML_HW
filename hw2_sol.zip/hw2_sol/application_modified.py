import math
import numpy as np
import linear_regression as lr
from sklearn.datasets import make_regression

# Note: please don't add any new package, you should solve this problem using only the packages above.
#-------------------------------------------------------------------------
'''
    Problem 2: Apply your Linear Regression
    In this problem, use your linear regression method implemented in problem 1 to do the prediction.
    Play with parameters alpha and number of epoch to make sure your test loss is smaller than 1e-2.
    Report your parameter, your train_loss and test_loss 
    Note: please don't use any existing package for linear regression problem, use your own version.
'''

#--------------------------

n_samples = 200
X,y = make_regression(n_samples= n_samples, n_features=4, random_state=1)
y = np.asmatrix(y).T
X = np.asmatrix(X)
Xtrain, Ytrain, Xtest, Ytest = X[::2], y[::2], X[1::2], y[1::2]

#########################################
## INSERT YOUR CODE HERE


alpha = np.linspace(0.1,1.3,13)
#alpha = np.linspace(0.007,0.01,4)
epoch = 2000
Iterations = [0 for i in range(len(alpha))]
Train_Cost = [0 for i in range(len(alpha))]
Test_Cost = [0 for i in range(len(alpha))]
Parameters = np.matrix([[0.0 for i in range(4)] for j in range(len(alpha))])
k=0

for a in alpha:    
    LTrain = [0.0 for i in range(epoch)]
    LTest = [0.0 for i in range(epoch)]
    W = [0.0 for i in range(epoch)]
    
    for i in range(epoch):
        w = lr.train(Xtrain,Ytrain,a,i)
        y_train_pred = lr.compute_yhat(Xtrain, w)   
        y_test_pred = lr.compute_yhat(Xtest, w)
        L_train = lr.compute_L(y_train_pred,Ytrain)
        L_test = lr.compute_L(y_test_pred,Ytest)
        if L_test < 0.01:
            Iterations[k] = i
            Train_Cost[k] = L_train
            Test_Cost[k] = L_test
            Parameters[k] = np.array(w).T
            break
        elif i == 10000:
            Iterations[k] = i
            Train_Cost[k] = L_train
            Test_Cost[k] = L_test
            Parameters[k] = np.array(w).T
    k+=1


import matplotlib.pyplot as plt
import pandas as pd

plt.figure()
plt.plot(alpha,Iterations,c='b')
plt.xlabel('Learning rate')
plt.ylabel('Epoch to reach L_Test < 0.01')
plt.title('Learning rate vs Epoch')
plt.savefig('Epoch_vs_alpha_huge')

plt.figure()
plt.plot(alpha,Train_Cost,c='r',label='Training Cost')
plt.plot(alpha,Test_Cost,c='g',label='Testing Cost')
plt.xlabel('Learning rate')
plt.ylabel('Cost')
plt.title('Learning rate vs Cost')
plt.legend()
plt.savefig('Cost_vs_alpha_huge')

df = alpha
df = np.vstack((df,Iterations))
df = np.vstack((df,Train_Cost))
df = np.vstack((df,Test_Cost))
df = df.T
df = np.hstack((df,Parameters))

df = pd.DataFrame(df)
df = df.rename(columns = {0:'Learning_rate',1:'Min_Iterations',2:'Training_cost',3:'Testing_cost',4:'Theta_1',5:'Theta_2',6:'Theta_3',7:'Theta_4' })
df.to_excel("Parameters2.xlsx",index=False)
